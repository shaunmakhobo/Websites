<?php

$conn = mysqli_connect('localhost','root','','fontis_db') or die('connection failed');

?>
